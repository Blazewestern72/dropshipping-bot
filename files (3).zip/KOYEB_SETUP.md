# 🚀 Koyeb Setup Guide - FREE 24/7 Discord Bot Hosting

## ✅ Why Koyeb?
- ✅ **100% FREE forever** (no credit card needed!)
- ✅ **Never sleeps** - stays online 24/7
- ✅ **Fast deployment** - 5 minutes to setup
- ✅ **Auto-restart** if bot crashes
- ✅ **Global edge network** - fast performance

---

## 📋 What You Need
1. GitHub account (free)
2. Koyeb account (free)
3. Discord bot token
4. 10 minutes of your time

---

## 🎯 Step-by-Step Setup

### Step 1: Create GitHub Account (if you don't have one) - 2 minutes

1. Go to **https://github.com**
2. Click **"Sign up"**
3. Follow the steps to create account
4. Verify your email

---

### Step 2: Upload Bot Files to GitHub - 3 minutes

**Option A: Using GitHub Web Interface (Easiest)**

1. Go to **https://github.com**
2. Click the **"+"** icon (top right) → **"New repository"**
3. Fill in:
   - **Repository name:** `dropshipping-bot`
   - **Description:** My Discord dropshipping bot
   - **Public** or **Private** (your choice)
   - ✅ Check **"Add a README file"**
4. Click **"Create repository"**

5. Upload your files:
   - Click **"Add file"** → **"Upload files"**
   - Drag and drop these 3 files:
     - `bot.py`
     - `requirements.txt`
     - `Dockerfile`
   - Click **"Commit changes"**

**Option B: Using GitHub Desktop (If you prefer apps)**
- Download GitHub Desktop: https://desktop.github.com
- Drag your folder into the app
- Click "Publish repository"

---

### Step 3: Create Koyeb Account - 1 minute

1. Go to **https://app.koyeb.com/auth/signup**
2. Sign up using:
   - **GitHub account** (recommended - one click!)
   - Or use email
3. **No credit card required!**
4. Verify your email if needed

---

### Step 4: Deploy Your Bot on Koyeb - 4 minutes

1. **In Koyeb Dashboard:**
   - Click **"Create App"** or **"Create Service"**

2. **Select Source:**
   - Choose **"GitHub"**
   - Click **"Connect GitHub"** if not already connected
   - Authorize Koyeb to access your repos

3. **Select Repository:**
   - Find and select: `dropshipping-bot` (or whatever you named it)
   - Branch: `main` or `master`

4. **Builder:**
   - Select **"Dockerfile"** (it will auto-detect your Dockerfile)

5. **Environment Variables (IMPORTANT!):**
   - Click **"Add Variable"**
   - Name: `DISCORD_BOT_TOKEN`
   - Value: Paste your Discord bot token here
   - Click **"Add"**

6. **App Settings:**
   - **Name:** `dropshipping-bot` (or anything you like)
   - **Region:** Choose closest to you (or leave default)
   - **Instance Type:** Leave as **"Free"** (Nano)

7. **Deploy:**
   - Click **"Deploy"**
   - Wait 2-3 minutes for deployment

---

### Step 5: Verify Bot is Running

1. In Koyeb dashboard, you'll see:
   - ✅ **Status: Healthy** (green check)
   - Deployment logs showing "Bot is online!"

2. Go to your Discord server:
   - Bot should show as **online** (green status)
   - Type `/help` to test

**🎉 Your bot is now running 24/7 for FREE!**

---

## 📊 Managing Your Bot

### View Logs:
1. In Koyeb dashboard
2. Click your app
3. Go to **"Logs"** tab
4. See real-time bot activity

### Restart Bot:
1. Go to your app in Koyeb
2. Click **"Redeploy"**

### Update Bot Code:
1. Edit files on GitHub
2. Commit changes
3. Koyeb **auto-redeploys** (or click "Redeploy")

### Stop Bot:
1. Go to your app
2. Click **"Settings"**
3. Click **"Delete Service"**

---

## 🔧 Updating Your Bot

### Method 1: Edit on GitHub (Easiest)
1. Go to your GitHub repo
2. Click on `bot.py`
3. Click the **pencil icon** (Edit)
4. Make your changes
5. Click **"Commit changes"**
6. Koyeb auto-deploys the update!

### Method 2: Git Commands (Advanced)
```bash
git clone https://github.com/yourusername/dropshipping-bot
cd dropshipping-bot
# Edit files
git add .
git commit -m "Updated bot"
git push
```

---

## 💾 Data Persistence

**IMPORTANT:** Koyeb doesn't persist files between deploys!

Your `bot_data.json` will be lost if you redeploy. To fix this:

**Option 1: Use a Database (Recommended for business)**
- Add MongoDB Atlas (free)
- Or PostgreSQL
- I can help you add this!

**Option 2: Backup Manually**
- Download `bot_data.json` before redeploying
- Not ideal for production

**Want me to add database support?** Let me know!

---

## 📱 Monitoring Your Bot

### Check Status:
- Koyeb Dashboard: See if app is "Healthy"
- Discord: Check bot's online status

### View Metrics:
- Koyeb shows:
  - CPU usage
  - Memory usage
  - Request count
  - Uptime

---

## ⚠️ Important Notes

### Free Tier Limits:
- ✅ **Unlimited** runtime (24/7 forever!)
- ✅ **No sleep** (unlike Heroku/Render)
- ✅ 512MB RAM (enough for Discord bots)
- ✅ 0.1 CPU (plenty for small bots)

### Discord Bot Token:
- Keep it **SECRET**!
- Never commit it to GitHub
- Only in Koyeb environment variables

### Bot Permissions:
- Make sure bot has proper Discord permissions
- Enable both intents in Discord Developer Portal:
  - ☑️ SERVER MEMBERS INTENT
  - ☑️ MESSAGE CONTENT INTENT

---

## 🆘 Troubleshooting

### Bot shows "Unhealthy" in Koyeb:
1. Check logs for errors
2. Verify `DISCORD_BOT_TOKEN` is set correctly
3. Make sure token is valid

### Bot offline in Discord:
1. Check Koyeb status (should be "Healthy")
2. Verify intents are enabled
3. Check logs for connection errors

### "Application error" in logs:
1. Check your `bot.py` for syntax errors
2. Verify `requirements.txt` has `discord.py`
3. Make sure `Dockerfile` is correct

### Bot not responding to commands:
1. Wait 5-10 minutes for command sync
2. Check bot has proper permissions in server
3. Try `/help` command

### Deployment fails:
1. Check all 3 files are in GitHub
2. Verify `Dockerfile` syntax
3. Check logs in Koyeb

---

## 🎯 Next Steps

Now that your bot is live 24/7:

1. ✅ **Test all commands:**
   - `/addproduct` - Add products
   - `/products` - View catalog
   - `/createorder` - Test orders
   - `/stats` - Check analytics

2. ✅ **Invite to your server:**
   - Make sure bot is in your Discord
   - Give it proper roles/permissions

3. ✅ **Start using it:**
   - Add your real products
   - Start tracking orders
   - Monitor your business!

4. ✅ **Consider database:**
   - For data persistence
   - For scaling
   - I can help add this!

---

## 💡 Tips & Best Practices

### Security:
- ✅ Never share your bot token
- ✅ Use environment variables
- ✅ Make GitHub repo private (optional)

### Backups:
- Regularly download `bot_data.json`
- Or upgrade to database solution

### Updates:
- Test changes locally first
- Use GitHub for version control
- Koyeb auto-deploys on push

### Monitoring:
- Check logs regularly
- Monitor bot uptime
- Watch for errors

---

## 🚀 Advanced: Adding Database (Optional)

Want persistent data that survives redeploys?

**I can help you add:**
- MongoDB Atlas (free 512MB)
- PostgreSQL
- Redis for caching

**Just ask and I'll create the updated code!**

---

## 📞 Need Help?

**Common Issues:**

**Q: Bot keeps restarting?**
A: Check logs for errors, verify token is correct

**Q: Can't see commands in Discord?**
A: Wait 10 minutes for sync, check bot permissions

**Q: Data disappeared after redeploy?**
A: Koyeb doesn't persist files - need database

**Q: Want to add more features?**
A: Just ask! I can update the bot for you

---

## ✅ You're Done!

Your Discord dropshipping bot is now:
- ✅ Running 24/7 FREE
- ✅ On professional cloud infrastructure
- ✅ Auto-restarts if crashes
- ✅ Accessible from anywhere
- ✅ No electricity costs
- ✅ No computer needed

**Enjoy managing your dropshipping business from Discord!** 🎉

---

## 🎁 Bonus: Quick Reference

**Koyeb Dashboard:**
https://app.koyeb.com

**Your GitHub Repo:**
https://github.com/yourusername/dropshipping-bot

**Discord Developer Portal:**
https://discord.com/developers/applications

**To Update Bot:**
1. Edit files on GitHub
2. Commit changes
3. Koyeb auto-deploys

**To Check Status:**
1. Koyeb Dashboard → Your App
2. Look for green "Healthy" status

---

**Questions? Issues? Need features?** Just ask! 🚀
